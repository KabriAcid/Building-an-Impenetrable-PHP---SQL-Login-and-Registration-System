<?php
// I created this language file for the admin side of the plugin

// Heading
$_['heading_title'] = 'Advanced Security';

// Text
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified the advanced security settings!';
$_['text_edit'] = 'Edit Advanced Security Module';

// Entry
$_['entry_status'] = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify the advanced security settings!';
?>
